import time
from machine import Pin, I2C
import ssd1306


pir_sensor = Pin(15, Pin.IN)  # PIR sensor
ir_sensor = Pin(14, Pin.IN, Pin.PULL_DOWN)  # IR sensor

# Color sensor simulated with buttons
red_btn = Pin(13, Pin.IN, Pin.PULL_DOWN)
green_btn = Pin(12, Pin.IN, Pin.PULL_DOWN)
blue_btn = Pin(11, Pin.IN, Pin.PULL_DOWN)

# IR LED output pin
ir_led = Pin(10, Pin.OUT)

# --- OLED Setup ---

# --- OLED Setup ---
i2c = I2C(1, scl=Pin(3), sda=Pin(2))  # ✅ valid I2C pins on Pico W
oled = ssd1306.SSD1306_I2C(128, 64, i2c)


# --- Functions ---

def detect_color():
    if red_btn.value():
        return 1  # Red
    elif green_btn.value():
        return 2  # Green
    elif blue_btn.value():
        return 3  # Blue
    else:
        return 0  # No color selected

def display_data(pir, ir, color):
    oled.fill(0)  # Clear display

    oled.text(f"PIR: {pir}", 0, 0)
    oled.text(f"IR: {ir}", 0, 16)
    oled.text(f"Color: {color}", 0, 32)

    if color == 1:
        oled.text("Color: RED", 0, 48)
    elif color == 2:
        oled.text("Color: GREEN", 0, 48)
    elif color == 3:
        oled.text("Color: BLUE", 0, 48)
    else:
        oled.text("Color: NONE", 0, 48)

    oled.show()

# --- Main Program ---

def main():
    print("📡 Monitoring started...")

    while True:
        pir_state = pir_sensor.value()
        ir_state = ir_sensor.value()
        color_code = detect_color()

        print(f"📟 PIR: {pir_state}, IR: {ir_state}, Color: {color_code}")

        # LED control
        ir_led.value(ir_state)  # LED ON if IR is 1

        # Display on OLED
        display_data(pir_state, ir_state, color_code)

        time.sleep(1)

if __name__ == '__main__':
    main()
