import time
from machine import Pin, I2C
import network
import urequests
import ssd1306

# --- WiFi and Thingspeak setup ---
SSID = 'Wockwi-GUEST'
PASSWORD = ''
THINGSPEAK_API_KEY = 'ABK6IASEQ1J0BXCC'
THINGSPEAK_URL = 'http://api.thingspeak.com/update'

# --- Connect to WiFi ---
def connect_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    if not wlan.isconnected():
        print('Connecting to WiFi...')
        wlan.connect(SSID, PASSWORD)
        while not wlan.isconnected():
            time.sleep(0.5)
    print('WiFi connected:', wlan.ifconfig())

# --- Sensor and OLED setup ---

pir_sensor = Pin(15, Pin.IN)  # PIR sensor
ir_sensor = Pin(14, Pin.IN, Pin.PULL_DOWN)  # IR sensor

# Color sensor simulated with buttons
red_btn = Pin(13, Pin.IN, Pin.PULL_DOWN)
green_btn = Pin(12, Pin.IN, Pin.PULL_DOWN)
blue_btn = Pin(11, Pin.IN, Pin.PULL_DOWN)

# IR LED output pin
ir_led = Pin(10, Pin.OUT)

# OLED Setup
i2c = I2C(1, scl=Pin(3), sda=Pin(2))
oled = ssd1306.SSD1306_I2C(128, 64, i2c)

# --- Functions ---

def detect_color():
    if red_btn.value():
        return 1  # Red
    elif green_btn.value():
        return 2  # Green
    elif blue_btn.value():
        return 3  # Blue
    else:
        return 0  # No color selected

def display_data(pir, ir, color):
    oled.fill(0)  # Clear display
    oled.text(f"PIR: {pir}", 0, 0)
    oled.text(f"IR: {ir}", 0, 16)
    oled.text(f"Color: {color}", 0, 32)

    if color == 1:
        oled.text("Color: RED", 0, 48)
    elif color == 2:
        oled.text("Color: GREEN", 0, 48)
    elif color == 3:
        oled.text("Color: BLUE", 0, 48)
    else:
        oled.text("Color: NONE", 0, 48)

    oled.show()

def send_to_thingspeak(pir, ir, color):
    try:
        # ThingSpeak fields: field1 = PIR, field2 = IR, field3 = Color code
        url = f"{THINGSPEAK_URL}?api_key={THINGSPEAK_API_KEY}&field1={pir}&field2={ir}&field3={color}"
        response = urequests.get(url)
        response.close()
        print("Data sent to ThingSpeak")
    except Exception as e:
        print("Failed to send data:", e)

# --- Main Program ---

def main():
    connect_wifi()
    print("📡 Monitoring started...")

    while True:
        pir_state = pir_sensor.value()
        ir_state = ir_sensor.value()
        color_code = detect_color()

        print(f"📟 PIR: {pir_state}, IR: {ir_state}, Color: {color_code}")

        # LED control
        ir_led.value(ir_state)  # LED ON if IR is 1

        # Display on OLED
        display_data(pir_state, ir_state, color_code)

        # Send data to ThingSpeak
        send_to_thingspeak(pir_state, ir_state, color_code)

        time.sleep(15)  # ThingSpeak allows updates every 15 seconds minimum

if __name__ == '__main__':
    main()
